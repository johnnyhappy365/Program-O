<?php


const APP_ID = '9310528';
const API_KEY = '4ZAU7EIvot55uSEEUwV6RGBc';
const SECRET_KEY = 'P53DMBmFkK7XwSyvZaWMPTBCYnwvp1g6';